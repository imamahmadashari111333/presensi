<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link rel="shortcut icon" href="{{asset('img/icon/tk.png')}}">
  <title>Sistem Informasi TK Khalifah 25</title>
  <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css')}}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="{{asset('assets/css/bootstrap-select.min.css')}}">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.1/js/bootstrap-select.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="{{ asset('assets/jquery-jvectormap-1.2.2.css')}}">
  <link rel="stylesheet" href="{{ asset('assets/css/AdminLTE.min.css')}}">
  <link rel="stylesheet" href="{{ asset('assets/css/_all-skins.min.css')}}">
  <link rel="stylesheet" href="{{ asset('assets/css/dataTables.bootstrap.css')}}">
  <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css')}}">
  <link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet">
  <script>
    window.Laravel = {!! json_encode([
      'csrfToken' => csrf_token(),
      ]) !!};
    </script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
      <header class="main-header">
        <a href="{{url('/')}}" class="logo">
          <span class="logo-lg"><b>Admin</b></span>
        </a>
        <nav class="navbar navbar-static-top">
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <li>
                <a href="{{ url('/logout') }}" onclick="event.preventDefault(); 
                document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i>
                Logout</a>
                <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                  {{ csrf_field() }}</form>
                </li>
              </ul>
            </div>
          </nav>
        </header>
        <aside class="main-sidebar">
          <section class="sidebar">
            <ul class="sidebar-menu">
              <li class="header">MENU DATA SISWA</li>
              <li>
                <a href="{{url('/dashboard-admin')}}">
                  <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                  <span class="pull-right-container">
                  </span>
                </a>
              </li>
              <li class="treeview">
                <a href="#">
                  <i class="fa fa-user"></i>
                  <span>Data siswa</span>
                  <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                  </span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="{{url('/data-siswa')}}"><i class="fa fa-list"></i> List data siswa</a></li>
                  <li><a href="{{url('/kelas-kb')}}"><i class="fa fa-caret-right" aria-hidden="true"></i> KB</a></li>
                  <li><a href="{{url('/kelas-tka')}}"><i class="fa fa-caret-right" aria-hidden="true"></i> TK A</a></li>
                  <li><a href="{{url('/kelas-tkb')}}"><i class="fa fa-caret-right" aria-hidden="true"></i> TK B</a></li>
                  <li><a href="{{url('/tambah-siswa')}}"><i class="fa fa-edit"></i> Input data siswa</a></li>
                </ul>
              </li>
              <li class="header"> INFORMASI KEUANGAN (Bulanan)</li>
              <li><a href="{{url('/spp')}}"> <i class="fa fa-check"></i></i> <span>SPP</span></a></li>
              <li><a href="{{url('/daycare')}}"> <i class="fa fa-check"></i></i> <span>Day care</span></a></li>
              <li><a href="{{url('/antarjemput')}}"> <i class="fa fa-check"></i></i> <span>Antar Jemput</span></a></li>
              <li><a href="{{url('/extrakurikuler')}}"> <i class="fa fa-check"></i></i> <span>Extra Kurikuler</span></a></li>
              <li class="header"> INFORMASI TABUNGAN (Bulanan)</li>
              <li><a href="{{url('/tabungan')}}"> <i class="fa fa-check"></i></i> <span>Tabungan</span></a></li>
              <li class="header"> LAPORAN ADMINISTRASI (Angsuran)</li>
              <li><a href="{{url('/iuran')}}"> <i class="fa fa-check"></i></i> <span>Iuran Pendidikan</span></a></li>
              <li><a href="{{url('/seragam')}}"> <i class="fa fa-check"></i></i> <span>Seragam Anak</span></a></li>
              <li><a href="{{url('/extrawajib')}}"> <i class="fa fa-check"></i></i> <span>Extra Drumband</span></a></li>
              <li><a href="{{url('/parenting')}}"> <i class="fa fa-check"></i></i> <span>Parenting</span></a></li>
              <li><a href="{{url('/wakaf')}}"> <i class="fa fa-check"></i></i> <span>Wakaf</span></a></li>       
            </ul>
          </section>
        </aside>
        <div class="content-wrapper">
          @yield('content')
        </div>
        <footer class="main-footer">
          <strong>Copyright &copy; 2017 TK Khalifah Semarang.</strong> All rights
          reserved.
        </footer>
      </div>
      <script src="{{ asset('assets/js/app.min.js')}}"></script>