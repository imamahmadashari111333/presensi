@extends('layouts.alert')
@extends('layouts.app-admin')
@section('content')
<section class="content-header">
</section>
<section class="content">
  <div class="row">
    <div class="clearfix visible-sm-block"></div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-12">
            <div class="col-md-8">
              <h3 style="font-family: impact;">
                @foreach( $nama as $row )
                  {{$row->nm_lengkap}}
                @endforeach
              </h3>
              <a href="{{url('/tabungan')}}"><button class="btn btn-default"><i class="fa fa-arrow-circle-left"></i> Kembali</button></a>
              <a href="{{url('downloadExcel/xlsx')}}" target="_blank" class="btn btn-info"><i class="fa fa-download"></i> Download (.xlsx)</i></a>
            </div>
            <div class="col-md-4">
              <div class="alert alert-info">
                @foreach($totaltabungan as $row)
                  <h3>Saldo: Rp. {{ number_format($row->saldo, 2) }}</h3>
                @endforeach
              </div>
            </div>
              <hr>
              <div class="col-md-6">
              @if (count($tabunganmasuk) > 0)
              <i class="fa fa-sign-in" aria-hidden="true"></i> Data tabungan masuk<hr>
              <table class="table">
                    <tr>
                      <th>No</th>
                      <th>Masuk (Rp)</th>
                      <th>Bulan</th>
                      <th>Tanggal menabung</th>
                      <th>Aksi</th>
                    </tr>
                    <?php $i = 1; ?>
                    @foreach( $tabunganmasuk as $row )
                    <tr>
                      <td width="5%">{{ $i }}</td>
                      <td>{{ $row->masuk }}</td>
                      <td>{{ $row->nm_bulan }}</td>
                      <td>{{ $row->created_at }}</td>
                      <td>
                        <a href="{!! url('/'.$row->id.'/delete-tabungan') !!}">
                          <button class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </a>
                      </td>
                    </td>
                  </tr>
                  <?php $i++; ?>
                  @endforeach
              </table>
              @else
              Belum ada tabungan !
              @endif
              </div>
              <div class="col-md-6">
              @if (count($tabungankeluar) > 0)
              <i class="fa fa-sign-out" aria-hidden="true"></i> Data tabungan keluar<hr>
              <table class="table">
                    <tr>
                      <th>No</th>
                      <th>Keluar (Rp)</th>
                      <th>Bulan</th>
                      <th>Keterangan</th>
                      <th>Tanggal pengambilan</th>
                      <th>Aksi</th>
                    </tr>
                    <?php $i = 1; ?>
                    @foreach( $tabungankeluar as $row )
                    <tr>
                      <td width="5%">{{ $i }}</td>
                      <td>{{ $row->keluar }}</td>
                      <td>{{ $row->nm_bulan }}</td>
                      <td>{{ $row->keterangan }}</td>
                      <td>{{ $row->created_at }}</td>
                      <td>
                        <a href="{!! url('/'.$row->id.'/delete-tabungan') !!}">
                          <button class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </a>
                      </td>
                    </td>
                  </tr>
                  <?php $i++; ?>
                  @endforeach
              </table>
              </div>    
              @else
              @endif
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection
