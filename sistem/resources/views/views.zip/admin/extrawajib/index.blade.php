@extends('layouts.alert')
@extends('layouts.app-admin')
@section('content')
<section class="content-header">
  <h1 style="font-family: impact;">Pembayaran Ekstra Wajib</h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-check"></i> extrawajib</a></li>
    <li class="active">Pembayaran Ekstra Wajib</li>
  </ol>
</section>
<section class="content">
  <div class="row">
    <div class="clearfix visible-sm-block"></div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-12">
              <div class="row">
                <div class="col-md-12">
                  <div class="panel panel-info">
                    <div class="panel panel-heading">
                      List data Pembayaran Ekstra Wajib
                    </div>
                    <div class="panel panel-body" style="margin-top: -20px;">
                      <div class="table table-responsive">
                        <table id="example1" class="table table-bordered">
                          <thead>
                            <tr class="info">
                              <th>No</th>
                              <th>Nama siswa</th>
                              <th>Kelas</th>
                              <th>Total extrawajib yang dibayar</th>
                              <th>Total angsuran extrawajib</th>
                              <th>Kurangnya</th>
                              <th>Detail</th>
                              <th>Aksi</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $i = 1; ?>
                            @foreach( $extrawajib as $row )
                            <tr>
                              <td>{{ $i }}</td>
                              <td>{{ $row->nm_lengkap }}</td>
                              <td align="center">{{ $row->kelas }}</td>
                              <td align="center">Rp. {{ number_format($row->total_extrawajib, 2) }}</td>
                              <td align="center">Rp. {{ number_format($row->pembayaran_extrawajib, 2) }}</td>
                              <td class="danger" align="center">
                                @if (!isset($row->kurangnya))
                                <h5>Belum input</h5>
                                @elseif ($row->total_extrawajib <= $row->pembayaran_extrawajib)
                                <h5>Lunas</h5>
                                @elseif ($row->total_extrawajib > $row->pembayaran_extrawajib)
                                Rp. {{ number_format($row->kurangnya, 2) }}
                                @endif
                              </td>
                              <td align="center">
                                <a href="{!! url('/'.$row->id.'/detail-extrawajib') !!}">
                                  <button class="btn btn-default" ><i class="fa fa-file-text-o"></i> Lihat rincian</button>
                                </a>
                              </td>
                              <td>
                                <a href="{!! url('/'.$row->id_extrawajib.'/delete-idextrawajib') !!}">
                                  <button class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                </a>
                              </td>
                            </td>
                          </tr>
                          <?php $i++; ?>
                          @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <a href="{{url('downloadextrawajib/xlsx')}}" target="_blank" class="btn btn-info"><i class="fa fa-download"></i></i></a>
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">
                 <i class="fa fa-plus"></i> Input data Pembayaran Ekstra Wajib
               </button>
               <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal1">
                 <i class="fa fa-plus"></i> Input data angsuran extrawajib
               </button>

               <!-- Modal -->
               <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <strong>
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Input angsuran extrawajib</strong>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      </div>
                      <div class="modal-body">
                        {!! Form::open(['url' => 'simpan-angsuranextrawajib']) !!}
                        Nama siswa:
                        <select name="id_siswa" class="selectpicker" data-live-search="true">
                          @foreach($nama as $row)
                          <option value="{{$row->id}}" data-tokens="mustard">{{$row->nm_lengkap}}</option>
                          @endforeach
                        </select><br><br>
                        Bulan:
                        <select name="id_bulan" class="selectpicker" data-live-search="true">
                          @foreach($bulan as $row)
                          <option value="{{$row->id}}" data-tokens="mustard">{{$row->nm_bulan}}</option>
                          @endforeach
                        </select><br><br>
                        Nominal:
                        <input type="number" min="0" name="nominal" class="form-control"><br>
                        Keterangan:
                        <textarea class="form-control" name="keterangan"></textarea><br>
                        <button class="btn btn-primary">Simpan</button>
                        {!! Form::close() !!}
                      </div>
                    </div>
                  </div>
                </div>
              <!-- Modal -->
               <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <strong>
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Input data pemberi extrawajib</strong>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      </div>
                      <div class="modal-body">
                        {!! Form::open(['url' => 'simpan-extrawajib']) !!}
                        Nama siswa:
                        <select name="id_siswa" class="selectpicker" data-live-search="true">
                          @foreach($nama as $row)
                          <option value="{{$row->id}}" data-tokens="mustard">{{$row->nm_lengkap}}</option>
                          @endforeach
                        </select><br><br>
                        Biaya ekstra wajib(Rp):
                        <input type="number" min="0" name="total_extrawajib" class="form-control"><br>
                        Keterangan:
                        <textarea class="form-control" name="keterangan"></textarea><br>
                        <button class="btn btn-primary">Simpan</button>
                        {!! Form::close() !!}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <script type="text/javascript" src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
            <script type="text/javascript" src="{{ asset('assets/js/jquery-1.11.1.min.js') }}"></script>
            <script type="text/javascript" src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
            <script type="text/javascript" src="{{ asset('assets/js/dataTables.bootstrap.js') }}"></script>
            <script type="text/javascript">
              $(function() {
                $('#example1').dataTable();
              });
            </script>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
