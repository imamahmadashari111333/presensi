@extends('layouts.alert')
@extends('layouts.app-admin')
@section('content')
<section class="content-header">
</section>
<section class="content">
  <div class="row">
    <div class="clearfix visible-sm-block"></div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-12">
              <h3 style="font-family: impact;">
                @foreach( $nama as $row )
                {{$row->nm_lengkap}}
                @endforeach
              </h3>
              <a href="{{url('/antarjemput')}}"><button class="btn btn-default"><i class="fa fa-arrow-circle-left"></i> Kembali</button></a>
              <a href="{{url('downloadExcel/xlsx')}}" target="_blank" class="btn btn-info"><i class="fa fa-download"></i> Download (.xlsx)</i></a><hr>
              <div class="table table-responsive">
                <table id="example1" class="table table-bordered">
                  <thead>
                    <tr class="info">
                      <th>No</th>
                      <th>Bulan</th>
                      <th>Nominal</th>
                      <th>Tanggal pembayaran</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1; ?>
                    @foreach( $dataantar as $row )
                    <tr>
                      <td width="5%">{{ $i }}</td>
                      <td>{{ $row->nm_bulan }}</td>
                      <td>{{ $row->nominal }}</td>
                      <td>{{ $row->created_at }}</td>
                      <td>
                        <a href="{!! url('/'.$row->id.'/delete-antarjemput') !!}">
                          <button class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </a>
                      </td>
                    </td>
                  </tr>
                  <?php $i++; ?>
                  @endforeach
                </tbody>
              </table>
            </div>
            <script type="text/javascript" src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
            <script type="text/javascript" src="{{ asset('assets/js/jquery-1.11.1.min.js') }}"></script>
            <script type="text/javascript" src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
            <script type="text/javascript" src="{{ asset('assets/js/dataTables.bootstrap.js') }}"></script>
            <script type="text/javascript">
              $(function() {
                $('#example1').dataTable();
              });
            </script>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection
