@extends('layouts.app-admin')
@section('content')
  <section class="content-header">
    <h1>
      Dashboard Admin
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard </li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-6 col-sm-6 col-xs-12">
        <div class="info-box">
          <span class="info-box-icon bg-red"><h6>Tk</h6><h1 style="margin-top: -5px;">25</h1></span>
          <div class="info-box-content">
            <span class="info-box-text"><strong> TK Khalifah 25 </strong></span>
            KB: 20 <br>
            TK A: 5 <br>
            TK B: 10
          </div>
        </div>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-12">
        <div class="info-box">
          <span class="info-box-icon bg-aqua"><h6>Tk</h6><h1 style="margin-top: -5px;">50</h1></span>
          <div class="info-box-content">
            <span class="info-box-text"><strong> TK Khalifah 50 </strong></span>
            KB: 20 <br>
            TK A: 5 <br>
            TK B: 10
          </div>
        </div>
      </div>
    </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="clearfix visible-sm-block"></div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-header with-border">
            <h4 class="box-title">Selamat datang <strong>{{Auth::user()->name}}</strong></h4>
            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
              </button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
          <div class="box-footer">
            <div class="row">
              <div class="col-sm-12">
                <div class="well">
                Selamat datang di sistem informasi TK khalifah.<br>
                Di sistem ini anda dapat menginputkan data siswa baru dan data pembayaran seperti: pembayaran SPP, Daycare, Antar Jemput, Extra Kurikuler, Tabungan, Iuran pendidikan, Seragam Anak, Extra Drumband, Parentinng dan Iuran Wakaf.<br>
                Sistem ini nantinya 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  @endsection
