@extends('layouts.alert')
@extends('layouts.app-admin')
@section('content')
  <section class="content-header">
    <h1>
     Tambah data siswa
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Data siswa</a></li>
      <li class="active">Tambah data siswa</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="clearfix visible-sm-block"></div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-footer">
            <div class="row">
              <div class="col-sm-12">
                    <tr>
                    {!! Form::open(['url' => 'simpan-siswa']) !!}
                      <td width="95%">
                        <table class="table">
                          <tr>
                            <td class="info" width="20%"> Isi Data Siswa</td>
                            <td width="30%"><input type="text" class="form-control" name="nm_lengkap" placeholder="Nama lengkap">
                            <span class="text-danger">{{ $errors->first('nm_lengkap') }}</span</td>
                            <td class="warning" width="20%">Isi Data ayah</td>
                            <td width="30%"><input type="text" class="form-control" name="nm_ayah" placeholder="Nama lengkap"><span class="text-danger">{{ $errors->first('nm_ayah') }}</span></td></tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="NIS" placeholder="NIS">
                            <span class="text-danger">{{ $errors->first('NIS') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="status_ayah" placeholder="Status ayah">
                            <span class="text-danger">{{ $errors->first('status_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="NIK" placeholder="NIK">
                            <span class="text-danger">{{ $errors->first('NIK') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="agama_ayah"  placeholder="Agama">
                            <span class="text-danger">{{ $errors->first('agama_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="NISN" placeholder="NISN" >
                            <span class="text-danger">{{ $errors->first('NISN') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="email_ayah" placeholder="Email"></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="nm_panggilan" placeholder="Nama panggilan">
                            <span class="text-danger">{{ $errors->first('nm_panggilan') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="number" class="form-control" name="hp_ayah" placeholder="No. Handphone"><span class="text-danger">{{ $errors->first('hp_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td>
                              <select class="form-control" name="jenis_kelamin">
                                <option>- Jenis kelamin -</option>
                                <option>L</option>
                                <option>P</option>
                              </select><span class="text-danger">{{ $errors->first('jenis_kelamin') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="pekerjaan_ayah" placeholder="Pekerjaan"><span class="text-danger">{{ $errors->first('pekerjaan_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td>Tempat, Tanggal lahir<input type="text" class="form-control" name="tempat" placeholder="Tempat"><span class="text-danger">{{ $errors->first('tempat') }}</span><br><input type="date" class="form-control" name="tanggal_lahir"><span class="text-danger">{{ $errors->first('tanggal_lahir') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><textarea type="text" rows="5" class="form-control" name="alamat_kantor_ayah" placeholder="Alamat kantor"></textarea><span class="text-danger">{{ $errors->first('alamat_kantor_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="status_anak" placeholder="Status anak">
                            <span class="text-danger">{{ $errors->first('status_anak') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="kewarganegaraan_ayah" placeholder="Kewarganegaraan">
                            <span class="text-danger">{{ $errors->first('kewarganegaraan_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="agama" placeholder="Agama">
                            <span class="text-danger">{{ $errors->first('agama') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="number" class="form-control" name="penghasilan_ayah" placeholder="Penghasilan">
                            <span class="text-danger">{{ $errors->first('penghasilan_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="text" class="form-control" name="kewarganegaraan" placeholder="Kewarganegaraan">
                            <span class="text-danger">{{ $errors->first('kewarganegaraan') }}</span></td>
                            <td class="warning" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="pendidikan_ayah" placeholder="Pendidikan">
                            <span class="text-danger">{{ $errors->first('pendidikan_ayah') }}</span></td>
                          </tr>
                          <tr>
                            <td class="info"></td>
                            <td><input type="number" class="form-control" name="anak_ke" placeholder="Anak ke-">
                            <span class="text-danger">{{ $errors->first('anak_ke') }}</span>
                            </td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%">Isi Keterangan Siswa</td>
                            <td width="30%"><input type="text" class="form-control" name="jarak" placeholder="Jarak Rumah"><span class="text-danger">{{ $errors->first('jarak') }}</span></td>
                            <td class="success" width="20%">Isi Data Ibu</td>
                            <td width="30%"><input type="text" class="form-control" name="nm_ibu" placeholder="Nama lengkap"><span class="text-danger">{{ $errors->first('nm_ibu') }}</span></td>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="transportasi" placeholder="Kendaraan yang digunakan untuk berangkat"></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="status_ibu" placeholder="Status ibu"><span class="text-danger">{{ $errors->first('status_ibu') }}</span></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%">
                              <select class="form-control" name="goldar">
                                <option>- Golongan darah -</option>
                                <option>A</option>
                                <option>B</option>
                                <option>AB</option>
                                <option>O</option>
                              </select><span class="text-danger">{{ $errors->first('goldar') }}</span>
                            </td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="agama_ibu"  placeholder="Agama"><span class="text-danger">{{ $errors->first('agama') }}</span></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="penyakit" placeholder="Penyakit yang pernah diderita siswa"></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="email_ibu" placeholder="Email"></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="nm_wali" placeholder="Nama wali"></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="number" class="form-control" name="hp_ibu" placeholder="No. Handphone"><span class="text-danger">{{ $errors->first('hp_ibu') }}</span></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="nm_siswa" placeholder="Nama siswa yang terdaftar"><span class="text-danger">{{ $errors->first('nm_siswa') }}</span></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="pekerjaan_ibu" placeholder="Pekerjaan"><span class="text-danger">{{ $errors->first('pekerjaan_ibu') }}</span></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><textarea type="text" rows="5" class="form-control" name="alamat" placeholder="Alamat siswa"></textarea><span class="text-danger">{{ $errors->first('alamat') }}</span></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><textarea type="text" rows="5" class="form-control" name="alamat_kantor_ibu" placeholder="Alamat kantor"></textarea></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%">
                              <select type="text" class="form-control" name="kelas">
                                <option>- Kelas -</option>
                                <option>KB</option>
                                <option>TK A</option>
                                <option>TK B</option>
                              </select></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="kewarganegaraan_ibu" placeholder="Kewarganegaraan"><span class="text-danger">{{ $errors->first('kewarganegaraan_ibu') }}</span></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="keterangan_waqaf" placeholder="Keterangan waqaf">
                            <span class="text-danger">{{ $errors->first('keterangan_waqaf') }}</span></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="number" class="form-control" name="penghasilan_ibu" placeholder="Penghasilan"></td>
                          </tr>
                          <tr>
                            <td class="danger" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="nm_terang" placeholder="Nama terang pemberi pernyataan">
                            <span class="text-danger">{{ $errors->first('nm_terang') }}</span></td>
                            <td class="success" width="20%"></td>
                            <td width="30%"><input type="text" class="form-control" name="pendidikan_ibu" placeholder="Pendidikan"><span class="text-danger">{{ $errors->first('pendidikan_ibu') }}</span></td>
                          </tr>
                        </table>
                        <div class="col-md-3 col-md-offset-9">
                        <button type="submit" class="btn btn-default" style="width: 49%;"><a href="{{url('/data-siswa')}}"><i class="fa fa-chevron-left" aria-hidden="true"></i> Kembali</a></button>
                        <button type="submit" class="btn btn-primary" style="width: 49%;">Simpan</button>
                        </div>
                        {!! Form::close() !!}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <script type="text/javascript" src="{{ asset('assets/js/jquery-1.11.1.min.js') }}"></script>
@endsection
