@extends('layouts.app-admin')
@section('content')
<section class="content-header">
  <h1>
   Edit data siswa
 </h1>
 <ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Data siswa</a></li>
  <li class="active">Edit data siswa</li>
</ol>
</section>
<section class="content">
  <div class="row">
    <div class="clearfix visible-sm-block"></div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-xs-12">
              {!! Form::model($data, ['url' => ['/update-siswa', $data->id]]) !!}
              @foreach ($datasiswa as $row)
              <div class="table table-responsive">
                <table class="table table-responsive" width="100%">
                  <tr>
                    <td class="info" width="20%">Nama lengkap</td>
                    <td width="30%"><input type="text" class="form-control" name="nm_lengkap" value="{{$row->nm_lengkap}}"></td>
                    <td class="warning" width="20%">Nama ayah</td>
                    <td width="30%"><input type="text" class="form-control" name="nm_ayah" value="{{$row->nm_ayah}}"></td>
                  </tr>
                  <tr>
                    <td class="info">NIS</td>
                    <td><input type="text" class="form-control" name="NIS" value="{{$row->NIS}}">
                    </td>
                    <td class="warning">Status ayah</td>
                    <td><input type="text" class="form-control" name="status_ayah" value="{{$row->status_ayah}}"></td>
                  </tr>
                  <tr>
                    <td class="info">NIK</td>
                    <td><input type="text" class="form-control" name="NIK" value="{{$row->NIK}}"></td>
                    <td class="warning">Agama</td>
                    <td><input type="text" class="form-control" name="agama_ayah"  value="{{$row->agama_ayah}}"></td>
                  </tr>
                  <tr>
                    <td class="info">NISN</td>
                    <td><input type="text" class="form-control" name="NISN" value="{{$row->NISN}}"></td>
                    <td class="warning">Email</td>
                    <td><input type="text" class="form-control" name="email_ayah" value="{{$row->email_ayah}}"></td>
                  </tr>
                  <tr>
                    <td class="info">Nama panggilan</td>
                    <td><input type="text" class="form-control" name="nm_panggilan" value="{{$row->nm_panggilan}}""></td>
                    <td class="warning">No. Handphone</td>
                    <td><input type="number" class="form-control" name="hp_ayah" value="{{$row->hp_ayah}}"></td>
                  </tr>
                  <tr>
                    <td class="info">Jenis kelamin</td>
                    <td>
                      <select class="form-control" name="jenis_kelamin">
                        <option>{{$row->jenis_kelamin}}</option>
                        <option>- Jenis kelamin -</option>
                        <option>L</option>
                        <option>P</option>
                      </select></td>
                      <td class="warning">Pekerjaan</td>
                      <td><input type="text" class="form-control" name="pekerjaan_ayah" value="{{$row->pekerjaan_ayah}}"></td>
                    </tr>
                    <tr>
                      <td class="info">Tempat, Tanggal lahir</td>
                      <td><input type="text" class="form-control" name="tempat" value="{{$row->tempat}}"><br><input type="date" class="form-control" name="tanggal_lahir" value="{{$row->tanggal_lahir}}"></td>
                      <td class="warning">Alamat kantor</td>
                      <td><textarea type="text" rows="5" class="form-control" name="alamat_kantor_ayah">{{$row->alamat_kantor_ayah}}</textarea></td>
                    </tr>
                    <tr>
                      <td class="info">Status anak</td>
                      <td><input type="text" class="form-control" name="status_anak" value="{{$row->status_anak}}"></td>
                      <td class="warning">Kewarganegaraan</td>
                      <td><input type="text" class="form-control" name="kewarganegaraan_ayah" value="{{$row->kewarganegaraan_ayah}}"></td>
                    </tr>
                    <tr>
                      <td class="info">Agama</td>
                      <td><input type="text" class="form-control" name="agama" value="{{$row->agama}}"></td>
                      <td class="warning">Penghasilan</td>
                      <td><input type="number" class="form-control" name="penghasilan_ayah" value="{{$row->penghasilan_ayah}}"></td>
                    </tr>
                    <tr>
                      <td class="info">Kewarganegaraan</td>
                      <td><input type="text" class="form-control" name="kewarganegaraan" value="{{$row->kewarganegaraan}}"></td>
                      <td class="warning">Pendidikan</td>
                      <td><input type="text" class="form-control" name="pendidikan_ayah" value="{{$row->pendidikan_ayah}}"></td>
                    </tr>
                    <tr>
                      <td class="info">Anak ke-</td>
                      <td><input type="number" class="form-control" name="anak_ke" value="{{$row->anak_ke}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Jarak rumah</td>
                      <td><input type="text" class="form-control" name="jarak" value="{{$row->jarak}}"></td>
                      <td class="success">Nama ibu</td>
                      <td><input type="text" class="form-control" name="nm_ibu" value="{{$row->nm_ibu}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Transportasi yang digunakan</td>
                      <td><input type="text" class="form-control" name="transportasi" value="{{$row->transportasi}}"></td>
                      <td class="success">Status ibu</td>
                      <td><input type="text" class="form-control" name="status_ibu" value="{{$row->status_ibu}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Golongan darah</td>
                      <td>
                        <select class="form-control" name="goldar">
                          <option>{{$row->goldar}}</option>
                          <option>- GolDar -</option>
                          <option>A</option>
                          <option>B</option>
                          <option>AB</option>
                          <option>O</option>
                        </select>
                      </td>
                      <td class="success">Agama</td>
                      <td><input type="text" class="form-control" name="agama_ibu"  value="{{$row->agama_ibu}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Penyakit</td>
                      <td><input type="text" class="form-control" name="penyakit" value="{{$row->penyakit}}"></td>
                      <td class="success">Email</td>
                      <td><input type="text" class="form-control" name="email_ibu" value="{{$row->email_ibu}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Nama wali</td>
                      <td><input type="text" class="form-control" name="nm_wali" value="{{$row->nm_wali}}"></td>
                      <td class="success">No. Handphone</td>
                      <td><input type="number" class="form-control" name="hp_ibu" value="{{$row->hp_ibu}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Nama siswa</td>
                      <td><input type="text" class="form-control" name="nm_siswa" value="{{$row->nm_siswa}}"></td>
                      <td class="success">Pekerjaan</td>
                      <td><input type="text" class="form-control" name="pekerjaan_ibu" value="{{$row->pekerjaan_ibu}}"></td>
                    </tr>
                    <tr>
                      <td class="danger">Alamat</td>
                      <td><textarea type="text" rows="5" class="form-control" name="alamat">{{$row->alamat}}</textarea></td>
                      <td class="success">Alamat kantor</td>
                      <td><textarea type="text" rows="5" class="form-control" name="alamat_kantor_ibu">{{$row->alamat_kantor_ibu}}</textarea></td>
                    </tr>
                    <tr>
                      <td class="danger">Kelas</td>
                      <td>
                        <select type="text" class="form-control" name="kelas" value="{{$row->kelas}}">
                          <option>- Kelas -</option>
                          <option>KB</option>
                          <option>TK A</option>
                          <option>TK B</option>
                        </select></td>
                        <td class="success">Kewarganegaraan</td>
                        <td><input type="text" class="form-control" name="kewarganegaraan_ibu" value="{{$row->kewarganegaraan}}"></td>
                      </tr>
                      <tr>
                        <td class="danger">Keterangan waqaf</td>
                        <td><input type="text" class="form-control" name="keterangan_waqaf" value="{{$row->keterangan_waqaf}}"></td>
                        <td class="success">Penghasilan</td>
                        <td><input type="number" class="form-control" name="penghasilan_ibu" value="{{$row->penghasilan_ibu}}"></td>
                      </tr>
                      <tr>
                        <td class="danger">Nama terang</td>
                        <td><input type="text" class="form-control" name="nm_terang" value="{{$row->nm_terang}}"></td>
                        <td class="success">Pendidikan</td>
                        <td><input type="text" class="form-control" name="pendidikan_ibu" value="{{$row->pendidikan_ibu}}"></td>
                      </tr>
                    </table>
                  </div>
                  <div class="col-md-3 col-md-offset-9">
                    <button type="submit" class="btn btn-default" style="width: 49%;"><a href="{{url('/data-siswa')}}">Kembali</a></button>
                    <button type="submit" class="btn btn-primary" style="width: 49%;">Simpan</button>
                  </div>
                  @endforeach
                  {!! Form::close() !!}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<script type="text/javascript" src="{{ asset('assets/js/jquery-1.11.1.min.js') }}"></script>
@endsection
