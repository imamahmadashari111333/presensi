@extends('layouts.app-admin')
@section('content')
  <section class="content-header">
    <h1>
     List data siswa TK B
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> TK B</a></li>
      <li class="active">List data siswa</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="clearfix visible-sm-block"></div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-footer">
            <div class="row">
              <div class="col-sm-12">
              <div class="table table-responsive">
                <table id="example1" class="table table-bordered">
                  <thead>
                    <tr class="info">
                      <th>No</th>
                      <th>Data lengkap</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1; ?>
                    @foreach( $datasiswa as $row )
                    <tr>
                      <td width="5%">{{ $i }}</td>
                      <td width="95%">
                        <table class="table">
                          <tr>
                            <td class="info" width="20%">Nama lengkap</td>
                            <td width="30%">{{$row->nm_lengkap}}</td>
                            <td class="warning" width="20%">Nama ayah</td>
                            <td width="30%">{{$row->nm_ayah}}</td>
                          </tr>
                          <tr>
                            <td class="info">NIS</td>
                            <td>{{$row->NIS}}</td>
                            <td class="warning">Pekerjaan Ayah</td>
                            <td>{{$row->pekerjaan_ayah}}</td>
                          </tr>
                          <tr>
                            <td class="info">NIK</td>
                            <td>{{$row->NIK}}</td>
                            <td class="warning">No. Handphone</td>
                            <td>{{$row->hp_ayah}}</td>
                          </tr>
                          <tr>
                            <td class="info">NISN</td>
                            <td>{{$row->NISN}}</td>
                            <td class="warning">Nama ibu</td>
                            <td>{{$row->nm_ibu}}</td>
                          </tr>
                          <tr>
                            <td class="info">Nama panggilan</td>
                            <td>{{$row->nm_panggilan}}</td>
                            <td class="warning">Pekerjaan ibu</td>
                            <td>{{$row->pekerjaan_ibu}}</td>
                          </tr>
                          <tr>
                            <td class="info">Jenis kelamin</td>
                            <td>{{$row->jenis_kelamin}}</td>
                            <td class="warning">No. Handphone</td>
                            <td>{{$row->hp_ibu}}</td>
                          </tr>
                          <tr>
                            <td class="info">Tempat, Tanggal lahir</td>
                            <td>{{$row->tempat}}, {{$row->tanggal_lahir}}</td>
                            <td class="warning">Alamat</td>
                            <td>{{$row->alamat}}</td>
                          </tr>
                          <tr>
                            <td class="info">Status anak</td>
                            <td>{{$row->status_anak}}</td>
                            <td class="warning">Golongan darah</td>
                            <td>{{$row->goldar}}</td>
                          </tr>
                          <tr>
                            <td class="info">Agama</td>
                            <td>{{$row->agama}}</td>
                            <td class="warning">Nama wali</td>
                            <td>{{$row->nm_wali}}</td>
                          </tr>
                          <tr>
                            <td class="info">Kewarganegaraan</td>
                            <td>{{$row->kewarganegaraan}}</td>
                          </tr>
                          <tr>
                            <td class="info">Anak ke-</td>
                            <td>{{$row->anak_ke}}</td>
                          </tr>
                          <tr>
                            <td class="info">Kelas</td>
                            <td>{{$row->kelas}}</td>
                          </tr>
                        </table>
                      </td>
                      <td>
                        <a href="{!! url('/'.$row->id.'/edit-siswa') !!}">
                        <button class="btn btn-default btn-block"><i class="fa fa-edit"></i></button><br>
                        </a>
                        <a href="{!! url('/'.$row->id.'/delete-siswa') !!}">
                        <button class="btn btn-danger btn-block"><i class="fa fa-trash"></i></button>
                        </a>
                        </td>
                      </td>
                    </tr>
                    <?php $i++; ?>
                    @endforeach
                  </tbody>
                </table>
                </div>
                <script type="text/javascript" src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
                <script type="text/javascript" src="{{ asset('assets/js/jquery-1.11.1.min.js') }}"></script>
                <script type="text/javascript" src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
                <script type="text/javascript" src="{{ asset('assets/js/dataTables.bootstrap.js') }}"></script>
                <script type="text/javascript">
                  $(function() {
                    $('#example1').dataTable();
                  });
                </script>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
@endsection
